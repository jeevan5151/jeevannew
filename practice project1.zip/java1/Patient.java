package java1;

public class Patient {


	//Properties/Field / Variables
		String name;
		int id;
		String dob;
		float age;
		String gender;
		String speciality;
		
	
		
		
		//Methods / Function / OPERATIONS
		void DetailPatient(){
			// method body
			
			System.out.println("This id patient details...");
		}
		
       float getAge(){
    	   return age;
       }
       
       void setAge(float newAge) {
    	   this.age=newAge;
       }
	}