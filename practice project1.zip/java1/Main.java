package java1;

public class Main {

	
		public static void main(String[] args) {
				Docter d1 = new Docter();
				d1.name="Madan";
				d1.age=56.3f;
				
				System.out.println("Docter's name is "+ d1.name);
				System.out.println("Doctor's age is "+ d1.age);
				
				d1.examinPatient();
				d1.setAge(100.5f);
				
				System.out.println("Docter's name is"+ d1.age);
				System.out.println("");
				Docter d2 = new Docter();
				d1.name="Raman";
				d1.age=40.3f;
				System.out.println("Secon Docter's name is"+ d2.name);
				System.out.println("Secon Docter's age is"+ d2.age);
				
				d2.examinPatient();
				d2.setAge(50.0f);
				System.out.println("Secon Docter's age is"+ d2.age);

			}

		}

	


