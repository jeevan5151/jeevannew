package java1;

public class Docter {


	//Properties/Field / Variables
		String name;
		int id;
		float age;
		
		String speciality;
		
		
		//Methods / Function / OPERATIONS
		void examinPatient(){
			// method body
			
			System.out.println("Examing the patient...");
		}
		
       float getAge(){
    	   return age;
       }
       
       void setAge(float newAge) {
    	   this.age=newAge;
       }
	}


